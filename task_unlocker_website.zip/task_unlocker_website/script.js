const defaults = {
  title: "Join our Roblox group",
  description: "Visit our Roblox group and join to support the community.",
  taskUrl: "https://www.roblox.com/",
  destination: "https://l1nq.com/x0zjl5g"
};
const $ = id => document.getElementById(id);
const settingKeys = ["title", "description", "taskUrl", "destination"];
function loadSettings() {
  let saved = {};
  try { saved = JSON.parse(localStorage.getItem("unlockhub-settings") || "{}"); } catch {}
  const s = {...defaults, ...saved};
  $("taskTitle").textContent = s.title;
  $("taskDescription").textContent = s.description;
  $("taskLink").href = safeUrl(s.taskUrl, defaults.taskUrl);
  $("destinationLink").href = safeUrl(s.destination, defaults.destination);
  $("inputTitle").value = s.title;
  $("inputDescription").value = s.description;
  $("inputTaskUrl").value = s.taskUrl;
  $("inputDestination").value = s.destination;
}
function safeUrl(value, fallback) {
  try { const u = new URL(value); return ["http:", "https:"].includes(u.protocol) ? u.href : fallback; }
  catch { return fallback; }
}
function unlock() {
  $("unlockBox").classList.remove("hidden");
  $("statusPill").textContent = "SELF-CONFIRMED";
  $("statusPill").classList.add("done");
  $("completeBtn").textContent = "Task confirmed ✓";
  $("completeBtn").disabled = true;
  $("completeBtn").style.opacity = ".65";
}
$("completeBtn").addEventListener("click", unlock);
$("adminToggle").addEventListener("click", () => $("adminPanel").classList.toggle("hidden"));
$("closeAdmin").addEventListener("click", () => $("adminPanel").classList.add("hidden"));
$("settingsForm").addEventListener("submit", event => {
  event.preventDefault();
  const settings = {
    title: $("inputTitle").value.trim() || defaults.title,
    description: $("inputDescription").value.trim() || defaults.description,
    taskUrl: safeUrl($("inputTaskUrl").value, defaults.taskUrl),
    destination: safeUrl($("inputDestination").value, defaults.destination)
  };
  localStorage.setItem("unlockhub-settings", JSON.stringify(settings));
  loadSettings();
  $("saveMessage").textContent = "Settings saved in this browser.";
  setTimeout(() => $("saveMessage").textContent = "", 3000);
});
$("resetSettings").addEventListener("click", () => {
  localStorage.removeItem("unlockhub-settings");
  localStorage.removeItem("unlockhub-complete");
  loadSettings();
  $("unlockBox").classList.add("hidden");
  $("statusPill").textContent = "INCOMPLETE";
  $("statusPill").classList.remove("done");
  $("completeBtn").textContent = "I completed the task";
  $("completeBtn").disabled = false;
  $("completeBtn").style.opacity = "1";
  $("saveMessage").textContent = "Defaults restored.";
});
loadSettings();
